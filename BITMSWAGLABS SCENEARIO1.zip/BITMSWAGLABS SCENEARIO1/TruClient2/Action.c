//   *****************************************************************************************************************************************
//   ****   PLEASE NOTE: This is a READ-ONLY representation of the actual script. For editing please press the "Develop Script" button.   ****
//   *****************************************************************************************************************************************

Action()
{
	truclient_step("1", "Navigate to 'https://www.saucedemo.com/'", "snapshot=Action_1.inf");
	lr_start_transaction("Login");
	truclient_step("3", "Login", "snapshot=Action_3.inf");
	{
		truclient_step("3.1", "Click on Username textbox", "snapshot=Action_3.1.inf");
		truclient_step("3.2", "Type username in Username textbox", "snapshot=Action_3.2.inf");
		truclient_step("3.3", "Click on Password passwordbox", "snapshot=Action_3.3.inf");
		truclient_step("3.4", "Type ******** in Password passwordbox", "snapshot=Action_3.4.inf");
		truclient_step("3.6", "Click on Login button", "snapshot=Action_3.6.inf");
		lr_end_transaction("Login",0);
	}
	lr_start_transaction("AddToCart");
	truclient_step("5", "Click on Add to cart button", "snapshot=Action_5.inf");
	truclient_step("7", "Click on 1", "snapshot=Action_7.inf");
	lr_end_transaction("AddToCart",0);
	lr_start_transaction("Checkout");
	truclient_step("9", "Click on Checkout button", "snapshot=Action_9.inf");
	truclient_step("11", "Continue", "snapshot=Action_11.inf");
	{
		truclient_step("11.1", "Click on First Name textbox", "snapshot=Action_11.1.inf");
		truclient_step("11.2", "Type firstname in First Name textbox", "snapshot=Action_11.2.inf");
		truclient_step("11.4", "Click on Last Name textbox", "snapshot=Action_11.4.inf");
		truclient_step("11.5", "Type lastname in Last Name textbox", "snapshot=Action_11.5.inf");
		truclient_step("11.7", "Click on Zip/Postal Code textbox", "snapshot=Action_11.7.inf");
		truclient_step("11.8", "Type postalcode in Zip/Postal Code textbox", "snapshot=Action_11.8.inf");
		truclient_step("11.10", "Click on Continue button", "snapshot=Action_11.10.inf");
		lr_end_transaction("Checkout",0);
	}
	lr_start_transaction("CompleteOrder");
	truclient_step("13", "Click on Finish button", "snapshot=Action_13.inf");
	lr_start_transaction("Logout");
	truclient_step("15", "Click on Open Menu button", "snapshot=Action_15.inf");
	lr_end_transaction("CompleteOrder",0);
	truclient_step("16", "Click on Logout listitem", "snapshot=Action_16.inf");
	lr_end_transaction("Logout",0);

	return 0;
}
